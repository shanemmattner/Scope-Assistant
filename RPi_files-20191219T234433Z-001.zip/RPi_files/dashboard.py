import base64
import dash
import dash_html_components as html
import dash_core_components as dcc
import dash_table as dt
import paramiko
from dash.dependencies import Input, Output, State
from os import chdir

def sendCommand(command, ssh_client):
    stdin_, stdout_, stderr_ = ssh_client.exec_command(str(command))
    stdout_.channel.recv_exit_status()
    lines = stdout_.readlines()
    return lines

def processMessage(msgLists):
    col_names = []
    out_list  = []
    for x in range(len(msgLists)):
        temp_list = msgLists[x].split("\t") #split by tabs
        temp_filtered = [] #list to hold filtered list from this row
        for y in range(len(temp_list)): #go through each element of the split list
            if temp_list[y]: #if the split element has a value (is not a space) then append it to temp_list2
                temp_list[y] = temp_list[y].replace("\n","") #remove the \n if there is one present
                temp_filtered.append(temp_list[y])
            else:
                pass
        if x == 0: #if it's the first row then use those values as column names
            col_names = temp_filtered
        else:
            out_list.append(temp_filtered)

    return col_names,out_list

docks = ["Dock 1"]
one_sec_interval = dcc.Interval(
    id='one_sec',
    interval=3*1000, # in milliseconds
    n_intervals=0
)
chdir("/var/www/lab_app")
RH_logo = base64.b64encode(open('ritehite_logo.png', 'rb').read())

app=dash.Dash(__name__)
server=app.server
app.config.suppress_callback_exceptions = True #prevents errors if we reference components before they're defin

app.layout=html.Div(children=[
    html.Img(src='data:image/png;base64,{}'.format(RH_logo.decode()), width = 200),
    html.Div(id="table-id"),
    one_sec_interval])

columns_test = ['Param1','Param2','Param3']
rows_test = [['p1_x',7,0],['p2_x',20,1],['p3_x',-132,10]]
@app.callback(Output('table-id', 'children'),
              [Input('one_sec', 'n_intervals')])
def update_output(n):
     for x in docks:
        msg = """mysql -uroot -pRitehite.1 rdexdb -e "SELECT timestamp, radio_name, plio_value FROM v_point_log_points_devices WHERE radio_name = '"""
        msg = msg + x
        msg = msg + """' AND name = 'Anti-Sag' ORDER BY timestamp DESC LIMIT 1";"""
        ssh_client = paramiko.SSHClient() #create SSH client
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect('192.168.155.47', username = 'webadmin', password = 'Ritehite1') #connect to server
        data_raw = sendCommand(msg, ssh_client)
        ssh_client.close()
        col_list, value_list = processMessage(data_raw)
        data=[dict(zip(col_list, value_list[0]))]
        table = dt.DataTable(
                id = 'table',
                columns = [{"name": i, "id": i} for i in col_list],
                data=data)
        return table

app.run_server(host='0.0.0.0',debug=True )
